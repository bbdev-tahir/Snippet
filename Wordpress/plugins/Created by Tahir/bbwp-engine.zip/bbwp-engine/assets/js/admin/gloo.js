jQuery(document).ready(function ($) {
    $('.js-bbwp-engine-enable').on('click', function (event) {
        event.preventDefault();
        $(this).parents('.bbwp-engine-box').addClass('enabled').find('input[type="checkbox"]').prop('checked', true);

    });

    $('.js-bbwp-engine-disable').on('click', function (event) {
        event.preventDefault();
        $(this).parents('.bbwp-engine-box').addClass('enabled').find('input[type="checkbox"]').prop('checked', false);
    });

    $('.bbwp-engine-items input.flipswitch').on('change', function (event) {

        var checked = $(this).is(':checked'),
            name = $(this).attr('name');

        $.ajax({
            type: "POST",
            url: BBWPEngineData.ajaxUrl,
            data: {action: "bbwp_engine_update_options", module: name, status: checked},
            success: function (response) {

            }
        });
    });


});