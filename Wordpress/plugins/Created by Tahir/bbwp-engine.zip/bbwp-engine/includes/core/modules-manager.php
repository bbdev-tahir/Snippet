<?php
/**
 * Modules manager
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

if ( ! class_exists( 'BBWP_Engine_Modules' ) ) {

	/**
	 * Define Gloo_Modules class
	 */
	class BBWP_Engine_Modules {

		public $option_name = 'bbwp_engine_modules';
		private $modules = array();
		private $active_modules = array();
		private $unsatisfied_dependencies = array();

		/**
		 * Constructor for the class
		 */
		function __construct() {

			$this->preload_modules();
			$this->init_active_modules();
		}


		/**
		 * Activate module
		 *
		 * @return [type] [description]
		 */
		public function activate_module( $module ) {

			$modules = get_option( $this->option_name, array() );

			if ( ! in_array( $module, $modules ) ) {
				$modules[] = $module;
			}

			update_option( $this->option_name, $modules );

		}

		/**
		 * Returns path to file inside modules dir
		 *
		 * @param  [type] $path [description]
		 *
		 * @return [type]       [description]
		 */
		public function modules_path( $path ) {
			return bbwp_engine()->modules_path() . $path;
		}

		/**
		 * Preload modules
		 *
		 * @return void
		 */
		public function preload_modules() {

			$base_path   = bbwp_engine()->modules_path();
			$all_modules = apply_filters( 'bbwp_engine/available-modules', array(
				'db_backup'   => array('class' => 'BBWP_Module_DB_Backup', 'file' => $base_path . 'db-backup/db-backup.php'),
				'google_authenticator'   => array('class' => 'BBWP_Module_Google_Authenticator', 'file' => $base_path . 'google-authenticator/google-authenticator.php'),
			));

			require_once bbwp_engine()->plugin_path( 'includes/base/base-module.php' );

			$active_modules = $this->get_active_modules();
			if($active_modules && is_array($active_modules) && count($active_modules) >= 1){
				foreach ( $active_modules as $module) {
					if(isset($all_modules[$module])){
						require $all_modules[$module]['file'];
						$instance = new $all_modules[$module]['class'];
						$module_id    = $instance->module_id();
						$dependencies = $instance->module_dependencies();

						if ( $dependencies && is_array( $dependencies ) && count($dependencies) >= 1) {
							foreach ( $dependencies as $label => $value ) {

								if ( is_bool( $value ) ) { // value passed
									if ( ! $value ) { // dependency not satisfied
										$this->unsatisfied_dependencies[ $module_id ][] = $label;
									}
									continue;
								}

								// plugin path passed
								if ( ! function_exists( 'is_plugin_active' ) ) {
									include_once ABSPATH . 'wp-admin/includes/plugin.php';
								}

								if ( ! is_plugin_active( $value ) ) {
									$this->unsatisfied_dependencies[ $module_id ][] = $label;
								}
							}
						}
						$this->modules[ $module_id ] = $instance;
					}
				}
			}
		}


		public function get_unsatisfied_dependencies( $module_id = '' ) {

			if ( $module_id ) {
				return isset( $this->unsatisfied_dependencies[ $module_id ] ) ? $this->unsatisfied_dependencies[ $module_id ] : false;
			}

			return $this->unsatisfied_dependencies;

		}

		/**
		 * Initialize active modulles
		 *
		 * @return void
		 */
		public function init_active_modules() {

			$modules = $this->get_active_modules();

			if ( empty( $modules ) ) {
				return;
			}

			

			if($modules && is_array($modules) && count($modules) >= 1){
				foreach ( $modules as $key => $module ) {
				
					//if ( 'true' === $is_active ) {
	
						$module_instance = isset( $this->modules[ $module ] ) ? $this->modules[ $module ] : false;
						
						if ( $module_instance ) {
							call_user_func( array( $module_instance, 'module_init' ) );
							$this->active_modules[] = $module;
						}
					//}
				}
			}
		}

		/**
		 * Get all modules list in format required for JS
		 *
		 * @return [type] [description]
		 */
		public function get_all_modules_for_js() {

			$result = array();

			foreach ( $this->modules as $module ) {
				$result[] = array(
					'value' => $module->module_id(),
					'label' => $module->module_name(),
				);
			}

			return $result;

		}

		/**
		 * Get all modules list
		 *
		 * @return [type] [description]
		 */
		public function get_all_modules() {
			$result = array();
			foreach ( $this->modules as $module ) {
				$result[ $module->module_id() ] = $module->module_name();
			}

			return $result;
		}

		/**
		 * Get active modules list
		 *
		 * @return [type] [description]
		 */
		public function get_active_modules() {

			$active_modules = get_option( $this->option_name, array() );

			return $active_modules;
		}

		/**
		 * Check if pased module is currently active
		 *
		 * @param  [type]  $module_id [description]
		 *
		 * @return boolean            [description]
		 */
		public function is_module_active( $module_id = null ) {
			return in_array( $module_id, $this->active_modules );
		}

		/**
		 * Get module instance by module ID
		 *
		 * @param  [type] $module_id [description]
		 *
		 * @return [type]            [description]
		 */
		public function get_module( $module_id = null ) {
			return isset( $this->modules[ $module_id ] ) ? $this->modules[ $module_id ] : false;
		}

	}

}
