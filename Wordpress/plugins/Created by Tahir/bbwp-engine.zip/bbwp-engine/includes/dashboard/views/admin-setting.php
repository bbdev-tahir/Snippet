<?php

$all_modules    = bbwp_engine()->modules->get_all_modules();
$active_modules = bbwp_engine()->modules->get_active_modules();

include bbwp_engine()->plugin_path( 'includes/dashboard/views/common/admin-header.php' ); ?>
<div class="bbwp-engine-item-container">
    <img src="<?php echo $images_url . 'buildings.png' ?>" class="bbwp-engine-building"/>
    <div class="bbwp-engine-items">
        <!-- little engine -->
        <div class="bbwp-engine-feature">
            <div class="bbwp-engine-box">
                <div class="bbwp-engine-feature-title">
                    <img src="<?php echo $images_url . 'POWER GLOO header.jpg' ?>"/>
                </div>
                <div class="bbwp-engine-feature-status">
                    <a href="#" class="js-bbwp-engine-enable"><?php _e( 'Enable All' ); ?></a>
                    <a href="#" class="js-bbwp-engine-disable"><?php _e( 'Disable All' ); ?></a>
                </div>
                <ul>
                    <li>
                        <lable>
                            <input type="checkbox" class="flipswitch" value="1"
                                   name="db_backup" <?php echo in_array( 'db_backup', $active_modules ) ? 'checked="checked"' : ''; ?> />

							<?php _e( 'Database Backup', 'bbwp_engine_td' ); ?>
                            <small class="module-setting">
                                <a href="<?php echo admin_url( 'admin.php?page=bbwp-engine-zoho-setting' ); ?>"><?php _e( 'settings' ); ?></a>
                            </small>
                            <div class="bbwp-engine-tool">
                                <a href="#" class="tool-tip"></a>
                                <div class="tool-tip-content">
                                    <p><?php _e( '- Database Backup' ); ?></p>
                                    <p><?php _e( '- Upload Backup to Dropbox' ); ?></p>
                                </div>
                            </div>
                        </lable>
                    </li>  
                           
                </ul>
            </div>

            <div class="bbwp-engine-box">
                <div class="bbwp-engine-feature-title">
                    <img src="<?php echo $images_url . 'SUPERGLOO ADDONS header.jpg' ?>"/>
                </div>
                <ul>
                    <li>
                        <lable>
                            <input type="checkbox" class="flipswitch" value="1"
                                   name="google_authenticator" <?php echo in_array( 'google_authenticator', $active_modules ) ? 'checked="checked"' : ''; ?> />
							<?php _e( 'Google Authenticator', 'bbwp_engine_td' ); ?>
                            <small class="module-setting">
                                <a href="<?php echo admin_url( 'admin.php?page=bbwp-engine-zoho-setting' ); ?>"><?php _e( 'settings' ); ?></a>
                            </small>
                            <div class="bbwp-engine-tool">
                                <a href="#" class="tool-tip"></a>
                                <div class="tool-tip-content">
                                    <p><?php _e( 'Two-Factor Authentication' ); ?></p>
                                </div>
                            </div>
                        </lable>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Fluid dynamics -->
        <div class="bbwp-engine-feature">
            <div class="bbwp-engine-box">
                <div class="bbwp-engine-feature-title"><img
                            src="<?php echo $images_url . 'FLUID DYNAMIC title only.jpg' ?>"/></div>

                <div class="bbwp-engine-feature-status">
                    <a href="#" class="js-bbwp-engine-enable"><?php _e( 'Enable All' ); ?></a>
                    <a href="#" class="js-bbwp-engine-disable"><?php _e( 'Disable All' ); ?></a>
                </div>
                <ul>
                    <li>
                        <lable>
                            <input type="checkbox" class="flipswitch" value="1" name="gloo_dynamic_tag_maker" <?php echo in_array( 'gloo_dynamic_tag_maker', $active_modules ) ? 'checked="checked"' : ''; ?>/>
                            <?php _e( 'Data Sources Dynamic Tag' ); ?>
                        </lable>
                    </li>
                </ul>
            </div>
            <div class="bbwp-engine-support">
                <div class="bbwp-engine-fly">
                    <a href="https://desk.zoho.eu/portal/gloodesk/" target="_blank" class="bbwp-engine-btn-black"><?php _e( 'Support' ); ?></a>
                </div>
            </div>
        </div>
        <!-- Interactor -->
        <div class="bbwp-engine-feature">
            <div class="bbwp-engine-box">
                <div class="bbwp-engine-feature-title"><img
                            src="<?php echo $images_url . 'INTERACTOR TITLE ONLY.jpg' ?>"/></div>

                <div class="bbwp-engine-feature-status">
                    <a href="#" class="js-bbwp-engine-enable"><?php _e( 'Enable All' ); ?></a>
                    <a href="#" class="js-bbwp-engine-disable"><?php _e( 'Disable All' ); ?></a>
                </div>
                <ul>
                    
                    <li style="display: none;">
                        <div class="bbwp-engine-check">
                            <input type="checkbox" class="flipswitch" value="1" disabled/>
                        </div>
                        <?php _e( 'Ajax Module For Interactor' ); ?>
                    </li>
                </ul>

                <div class="bbwp-engine-support">
                    <div class="bbwp-engine-key">
                        <p><?php _e( 'Key:' ); ?></p>
                        <?php if(isset($gloo_license_info['key']) && !empty($gloo_license_info['key'])): ?>
                            <p><?php echo substr($gloo_license_info['key'],0,10).'********'; ?></p>
                        <?php else : ?>
                            <p><?php _e( 'NOT AVAILABLE' ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php include bbwp_engine()->plugin_path( 'includes/dashboard/views/common/admin-bbwp-engine-features.php' ); ?>
            </div>
        </div>
    </div>
</div>
<?php include bbwp_engine()->plugin_path( 'includes/dashboard/views/common/admin-bbwp-engine-footer.php' ); ?>
