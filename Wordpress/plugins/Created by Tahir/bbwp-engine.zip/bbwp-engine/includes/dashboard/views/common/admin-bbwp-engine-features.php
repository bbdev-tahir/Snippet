<div class="bbwp-engine-interactor">
    <div class="bbwp-engine-tutorials">
        <div class="bbwp-engine-image">
            <a href="http://gloo.ooo/fluid-dynamics" target="_blank">
                <img src="<?php echo $images_url . 'FLUID DYNAMIC.jpg' ?>"/>
                <div class="bbwp-engine-image-text"><?php _e('Documentation');?></div>
            </a>
        </div>
        <div class="bbwp-engine-image">
            <a href="http://gloo.ooo/little-engine" target="_blank">
                <img src="<?php echo $images_url . 'LITTLE ENGINE.jpg' ?>"/>
                <div class="bbwp-engine-image-text"><?php _e('More Info');?></div>
            </a>
        </div>
        <div class="bbwp-engine-image">
            <a href="http://gloo.ooo/interactor" target="_blank">
                <img src="<?php echo $images_url . 'INTERACTOR.jpg' ?>"/>
                <div class="bbwp-engine-image-text"><?php _e('User cases');?></div>
            </a>
        </div>
    </div>
    
    <div class="bbwp-engine-links">
        <a href="https://gloo.ooo"><?php _e( 'Visit Gloo.ooo' ); ?></a>
    </div>

    <ol>
        <li><a href="https://www.facebook.com/groups/286655332677410/" target="_blank"><img src="<?php echo $images_url . '003-facebook-circular-logo.png' ?>"/></a>
        </li>
        <li><a href=""><img src="<?php echo $images_url . '002-youtube.png' ?>"/></a></li>
        <li><a href=""><img src="<?php echo $images_url . '001-github-logo.png' ?>"/></a></li>
    </ol>
</div>