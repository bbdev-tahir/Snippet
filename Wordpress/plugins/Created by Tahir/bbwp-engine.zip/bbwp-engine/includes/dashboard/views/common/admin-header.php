<?php 
$gloo_license_info = get_option('bbwp_engine_license_info');
$images_url = bbwp_engine()->plugin_url( 'assets/images/admin/' ); 
$gloo_data = get_plugin_data(dirname(dirname(dirname(dirname(plugin_dir_path(__FILE__))))).'/bbwp-engine.php');
?>
<div class="wrap">
    <div class="bbwp-engine-wrapper">
        <!-- gloo bar -->
        <div class="bbwp-engine-bar">
            <div class="bbwp-engine-logo">
                <img src="<?php echo $images_url . 'logo-white-text.png' ?>"/>
            </div>
            <div class="bbwp-engine-login">
                <?php if(($admin_email = get_option('admin_email')) && !empty($admin_email)): ?>
                    <p><?php _e( 'Username : ' );  echo $admin_email; ?></p>
                <?php endif; 
                
                if(isset( $_GET['page'] ) && $_GET['page'] === bbwp_engine()->admin_page): ?>
                    <a class="bbwp-engine-login-link" href="<?php echo get_admin_url(get_current_blog_id(), 'admin.php?page=bbwp_engine_settings');?>"><?php _e( 'License' ); ?></a>
                <?php else: ?>
                    <a class="bbwp-engine-login-link" href="javascript:history.back();"><?php _e( 'Dashboard' ); ?></a>
                <?php endif; ?>
            </div>
        </div>

        <!-- gloo version -->
        <div class="bbwp-engine-version">
            <?php if(isset($gloo_data['Version']) && !empty($gloo_data['Version'])): ?>
                <p><?php _e( 'Ver : ' );  echo $gloo_data['Version']; ?></p>
            <?php endif; 

            if(isset( $_GET['page'] ) && $_GET['page'] === bbwp_engine()->admin_page): 
                if(isset($gloo_license_info['status']) && !empty($gloo_license_info['status']) && $gloo_license_info['status'] == 'activate'): ?>
                    <p><?php _e( 'Status :' ); ?><span class="bbwp-engine-active"><?php _e( ' Active' ); ?></span></p>
                <?php else :?>
                    <p><?php _e( 'Status :' ); ?><span class="bbwp-engine-inactive"><?php _e( ' Inactive' ); ?></span></p>
                <?php endif;
            endif; ?>
        </div>