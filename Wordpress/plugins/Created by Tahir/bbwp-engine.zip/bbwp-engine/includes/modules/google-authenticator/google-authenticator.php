<?php

// exit if file is called directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BBWP_Module_Google_Authenticator' ) ) {

	/**
	 * Define BBWP_Module_GOOGLE_Authenticator class
	 */
	class BBWP_Module_Google_Authenticator extends BBWP_Engine_Module_Base {

		public $instance = null;

		/**
		 * Module ID
		 *
		 * @return string
		 */
		public function module_id() {
			return 'google_authenticator';
		}

		/**
		 * Module name
		 *
		 * @return string
		 */
		public function module_name() {
			return __( 'Google Authenticator', 'bbwp_engine_td' );
		}

		/**
		 * Module init
		 *
		 * @return void
		 */
		public function module_init() {
			add_action( 'bbwp_engine/init', array( $this, 'create_instance' ) );
		}

		/**
		 * Create module instance
		 *
		 * @return [type] [description]
		 */
		public function create_instance(  ) {
			require  bbwp_engine()->modules_path( 'google-authenticator/inc/module.php' );
			$this->instance = \BBWP\Modules\GoogleAuthenticator\Module::instance();
		}

	}

}
