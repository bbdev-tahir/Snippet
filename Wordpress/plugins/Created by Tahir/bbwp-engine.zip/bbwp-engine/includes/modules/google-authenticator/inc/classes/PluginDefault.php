<?php
namespace OTW\ElementorFormCRM;

// exit if file is called directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PluginDefault extends Plugin{

	/******************************************/
	/***** class constructor **********/
	/******************************************/
  public function __construct(){
    
  }// construct function end here

  
} // BBWP_CustomFields class

