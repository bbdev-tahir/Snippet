<?php

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

/**
 * Class Plugin
 *
 * Main Plugin class
 */
if ( ! class_exists( 'BBWPEngine' ) ) {

	class BBWPEngine {

		/**
		 * Plugin Version
		 *
		 * @var string The plugin version.
		 */
		private $version = '0.0.1';

		public $modules;

		/**
		 * Instance
		 *
		 * @access private
		 * @static
		 *
		 * @var Plugin The single instance of the class.
		 */
		private static $_instance = null;

		/**
		 * Holder for base plugin path
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    string
		 */
		private $plugin_path = null;

		/**
		 * Holder for base plugin url
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    string
		 */
		private $plugin_url = null;


		/**
		 * Gloo menu page slug
		 *
		 * @var string
		 */
		public $admin_page = 'bbwp-engine-dashboard';

		public $dashboard;

		/**
		 * Instance
		 *
		 * Ensures only one instance of the class is loaded or can be loaded.
		 *
		 * @return Gloo An instance of the class.
		 * @access public
		 *
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 *  Plugin class constructor
		 *
		 * Register plugin action hooks and filters
		 *
		 * @access public
		 */
		public function __construct() {


			// Load files.
			add_action( 'init', array( $this, 'init' ), - 999 );

			// Register activation and deactivation hook.
			register_activation_hook( __FILE__, array( $this, 'activation' ) );
			register_deactivation_hook( __FILE__, array( $this, 'deactivation' ) );
			

		}

		public function init() {

			// require module files
			require $this->plugin_path( 'includes/core/modules-manager.php' );

			$this->admin_init();
			
			// initialize modules
			$this->modules = new BBWP_Engine_Modules();
			// add widgets category of gloo
			
			// enqueue styles
			do_action( 'bbwp_engine/init', $this );
		}


		public function admin_init() {
			if ( ! is_admin() ) {
				return;
			}

			require $this->plugin_path( 'includes/dashboard/manager.php' );

			$this->dashboard     = new BBWP_Engine_Dashboard();
		}


		/**
		 * Do some stuff on plugin activation
		 *
		 * @return void
		 * @since  1.0.0
		 */
		public function activation() {
			
		}

		/**
		 * Do some stuff on plugin activation
		 *
		 * @return void
		 * @since  1.0.0
		 */
		public function deactivation() {
		}

		/**
		 * Returns plugin version
		 *
		 * @return string
		 */
		public function get_version() {
			return $this->version;
		}


		/**
		 * Check if theme has elementor
		 *
		 * @return boolean
		 */
		public function has_elementor() {
			return defined( 'ELEMENTOR_VERSION' );
		}

		/**
		 * Check if theme has elementor
		 *
		 * @return boolean
		 */
		public function has_elementor_pro() {
			return defined( 'ELEMENTOR_PRO_VERSION' );
		}

		public function plugin_url( $path = null ) {

			if ( ! $this->plugin_url ) {
				$this->plugin_url = trailingslashit( plugin_dir_url( __FILE__ ) );
			}

			return $this->plugin_url . $path;
		}


		public function plugin_path( $path = null ) {

			if ( ! $this->plugin_path ) {
				$this->plugin_path = trailingslashit( plugin_dir_path( __FILE__ ) );
			}

			return $this->plugin_path . $path;
		}

		public function modules_path( $path = null ) {
			return $this->plugin_path( 'includes/modules/' ) . $path;
		}

	}
}

if ( ! function_exists( 'bbwp_engine' ) ) {
	/**
	 * Returns instance of the plugin class.
	 *
	 * @return Gloo
	 * @since  1.0.0
	 */
	function bbwp_engine() {
		return BBWPEngine::instance();
	}
}
// Instantiate Plugin Class
bbwp_engine();
