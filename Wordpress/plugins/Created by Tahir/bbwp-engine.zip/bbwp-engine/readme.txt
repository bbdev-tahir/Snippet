=== BBWP Engine ===
Contributors: gloo
Tags: gloo, elementor, addon
Requires at least: 4.7
Tested up to: 5.6
Stable tag: 1.0.93
Requires PHP: 7.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
