<?php
namespace ByteBunch\FluidDynamics;

class ElementorWidget extends \Elementor\Widget_Base {

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'fluid-dynamics' ),
			]
		);

		$this->add_control(
			'google_autocomplete',
			[
				'label' => __( 'Google Autocomplete', 'fluid-dynamics' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Google Autocomplete', 'fluid-dynamics' ),
			]
		);

		$this->end_controls_section();

	}

}