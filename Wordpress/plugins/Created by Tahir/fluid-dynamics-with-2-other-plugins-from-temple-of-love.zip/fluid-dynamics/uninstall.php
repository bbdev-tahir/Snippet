<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$prefix = 'bbwp_fluid_dynamics';
delete_option($prefix.'_options');