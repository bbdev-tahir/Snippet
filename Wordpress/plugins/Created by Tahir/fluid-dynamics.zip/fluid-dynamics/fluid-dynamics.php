<?php
namespace ByteBunch\FluidDynamics;
/*
Plugin Name: Fluid Dynamics
Plugin URI: https://bytebunch.com/
Description: Add the class {autocomplete_address} to any form input and make it compatible with Google Autocomplete Places API.
Author: ByteBunch
Version: 0.1
Stable tag:        0.1
Requires at least: 5.1
Tested up to: 5.2.4
Author URI: https://bytebunch.com
Text Domain:       fluid-dynamics
Domain Path:       /languages
License:           GPL v2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.txt

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version
2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
with this program. If not, visit: https://www.gnu.org/licenses/

*/

//use ByteBunch\BBWPInvitationSystem\BBWP_Invitation_System as BBWP_Invitation_System;

// exit if file is called directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


// constant for plugin directory path
define('BBWP_FLUID_DYNAMICS_URL', plugin_dir_url(__FILE__));
define('BBWP_FLUID_DYNAMICS_ABS', plugin_dir_path( __FILE__ ));
define('BBWP_FLUID_DYNAMICS_PLUGIN_FILE', plugin_basename(__FILE__));


// include the generic functions file.
include_once BBWP_FLUID_DYNAMICS_ABS.'inc/functions.php';
include_once BBWP_FLUID_DYNAMICS_ABS.'inc/autoload.php';

// add the data sanitization and validation class
if(!class_exists('BBWPSanitization'))
  include_once BBWP_FLUID_DYNAMICS_ABS.'inc/classes/BBWPSanitization.php';

FluidDynamics::instance();

