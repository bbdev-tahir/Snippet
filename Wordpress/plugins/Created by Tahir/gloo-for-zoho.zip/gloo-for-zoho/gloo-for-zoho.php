<?php
/**
 * Plugin Name: Gloo for Zoho
 * Description: Gloo for Zoho
 * Version:     0.0.1
 * Author:      Gloo
 * Author URI:  http://gloo.ooo
 * Text Domain: gloo_for_zoho_td
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

final class Gloo_For_Zoho {

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		//call appsero tracker
		$this->appsero_init_tracker_gloo_for_zoho();

		// Load translation
		add_action( 'init', array( $this, 'i18n' ) );

		// Init Plugin
		add_action( 'plugins_loaded', array( $this, 'init' ) );

	}


	/** * Initialize the plugin tracker * * @return void */

	public function appsero_init_tracker_gloo_for_zoho() {    

		global $gloo_for_zoho_license;

		if ( ! class_exists( '\Appsero\Client' ) ) {   
			require_once __DIR__ . '/includes/appsero/src/Client.php';
		}
		
		$client = new Appsero\Client( '8d9fb311-e085-46fc-b8b7-e58540e3e35c', 'Gloo for Zoho', __FILE__ );
		// Active insights    
		
		$client->insights()->init();    
		
		// Active automatic updater    
		
		$client->updater();    
		
		// Active license page and checker    
		
		$args = array(
			'type'       => 'submenu',
			'menu_title' => 'Gloo for Zoho License',
			'page_title' => 'Gloo for Zoho License Settings',
			'menu_slug'  => 'gloo_for_zoho_settings',
			'parent_slug' => 'gloo-for-zoho-dashboard',
	);

		$gloo_for_zoho_license = $client->license();
		$gloo_for_zoho_license->add_settings_page( $args );

		$gloo_for_zoho_license->set_option_key( 'gloo_for_zoho_license_info' );

	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function i18n() {
		load_plugin_textdomain( 'gloo_for_zoho_td' );
	}

	/*public function private_gloo_for_zoho() {
		global $wp_list_table;
		$hide       = array( 'gloo-suite/gloo-suite.php' );
		$my_plugins = $wp_list_table->items;
		foreach ( $my_plugins as $key => $val ) {
			if ( in_array( $key, $hide ) ) {
				unset( $wp_list_table->items[ $key ] );
			}
		}
	}*/

	/**
	 * Initialize the plugin
	 *
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed include the plugin class.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function init() {

		// Check if Elementor is installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_elementor_plugin' ] );

			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_minimum_php_version' ) );

			return;
		}
		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once( 'plugin.php' );

	}


	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'gloo_for_zoho' ),
			'<strong>' . esc_html__( 'Gloo For Zoho', 'gloo_for_zoho' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'gloo_for_zoho' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	public function admin_notice_missing_elementor_plugin() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Gloo For Zoho for Elementor 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'gloo_for_zoho' ),
			'<strong>' . esc_html__( 'Gloo For Zoho', 'gloo_for_zoho' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'gloo_for_zoho' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

}

// Instantiate gloo_for_zoho.
new Gloo_For_Zoho();
