<?php
/**
 * Base class for module
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

if ( ! class_exists( 'gloo_for_zoho_Module_Base' ) ) {

	/**
	 * Define Gloo_Module_Base class
	 */
	abstract class gloo_for_zoho_Module_Base {

		/**
		 * Module ID
		 *
		 * @return string
		 */
		abstract public function module_id();

		/**
		 * Module name
		 *
		 * @return string
		 */
		abstract public function module_name();

		/**
		 * Module init
		 *
		 * @return void
		 */
		abstract public function module_init();

	}

}
