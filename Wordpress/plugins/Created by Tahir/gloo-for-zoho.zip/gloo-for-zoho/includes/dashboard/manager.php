<?php
/**
 * Dashboard Manager
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'gloo_for_zoho_Dashboard' ) ) {

	/**
	 * Define Gloo_Dashboard class
	 */
	class gloo_for_zoho_Dashboard {


		/**
		 * Constructor for the class
		 */
		function __construct() {
//			add_action( 'admin_menu', array( $this, 'register_main_menu_page' ), 10 );
//			add_action( 'admin_init', array( $this, 'init_components' ), 99 );

			add_action( 'admin_menu', [ $this, 'gloo_setting_page' ] );
			add_action( 'admin_enqueue_scripts', [ $this, 'gloo_enqueue_admin_script' ] );
			add_action( 'wp_ajax_gloo_for_zoho_update_options', [ $this, 'update_options' ] );
			add_action( 'admin_head', [ $this, 'gloo_icon_alignment' ] );

		}

		public function update_options() {

			$status = $_POST['status'] === "true";
			$module = $_POST['module'];

			if ( ! $module ) {
				wp_send_json_error();
			}

			$option_name = gloo_for_zoho()->modules->option_name;
			$modules     = get_option( $option_name, array() );


			if ( ! in_array( $module, $modules ) ) {
				if ( $status ) {
					$modules[] = $module;
				}
			} else {
				$module_key = array_search( $module, $modules );
				if ( ! $status && $module_key !== false ) {
					unset( $modules[ $module_key ] );
				}
			}

			update_option( $option_name, $modules );

			wp_send_json_success();

		}

		public function gloo_enqueue_admin_script( $hook ) {

			if ( ! $this->is_dashboard() ) {
				return;
			}

			wp_enqueue_style( 'gloo-for-zoho', gloo_for_zoho()->plugin_url( 'assets/css/admin/gloo.css' ), null, gloo_for_zoho()->get_version() );
			wp_enqueue_script( 'gloo-for-zoho', gloo_for_zoho()->plugin_url( 'assets/js/admin/gloo.js' ), [ 'jquery' ], gloo_for_zoho()->get_version() );

			wp_localize_script( 'gloo-for-zoho', 'GlooForZohoData',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				)
			);

		}

		public function gloo_setting_page() {
			
			/* Main Settings Page */
			add_menu_page(
				'Gloo for Zoho',
				'Gloo for Zoho',
				'manage_options',
				gloo_for_zoho()->admin_page,
				[ $this, 'render_admin_page' ],
				gloo_for_zoho()->plugin_url( 'assets/images/admin/gloo-icon.png' )
			);

		}





		public function gloo_icon_alignment() {
			echo '<style>
			#toplevel_page_gloo-for-zoho-dashboard img {
				padding: 0;
				width: 19px;
    		height: 22px;
			}
			/*#adminmenu li#toplevel_page_gloo-dashboard .wp-first-item {
				display: none;
			}*/
		  </style>';
		}

		public function render_admin_page() {
			include gloo_for_zoho()->plugin_path( 'includes/dashboard/views/admin-gloo-setting.php' );
		}

		
		/**
		 * Check if is dashboard page
		 *
		 * @return boolean [description]
		 */
		public function is_dashboard() {

			if ( isset( $_GET['page'] ) ) {
				return ( 
					$_GET['page'] === gloo_for_zoho()->admin_page);
			}
		}

	}

}
