<?php
$gloo_license_info = get_option('gloo_for_zoho_license_info');
$all_modules    = gloo_for_zoho()->modules->get_all_modules();
$active_modules = gloo_for_zoho()->modules->get_active_modules();

include gloo_for_zoho()->plugin_path( 'includes/dashboard/views/common/admin-gloo-header.php' ); ?>
<div class="gloo-item-container">
    <img src="<?php echo $images_url . 'buildings.png' ?>" class="gloo-building"/>
    <div class="gloo-items">
        <!-- little engine -->
        <div class="gloo-feature">
            <div class="gloo-box">
                <div class="gloo-feature-title">
                    <img src="<?php echo $images_url . 'POWER GLOO header.jpg' ?>"/>
                </div>
                <div class="gloo-feature-status">
                    <a href="#" class="js-gloo-enable"><?php _e( 'Enable All' ); ?></a>
                    <a href="#" class="js-gloo-disable"><?php _e( 'Disable All' ); ?></a>
                </div>
                <ul>
                    <li>
                        <lable>
                            <input type="checkbox" class="flipswitch" value="1"
                                   name="zoho_crm_sync" <?php echo in_array( 'zoho_crm_sync', $active_modules ) ? 'checked="checked"' : ''; ?> />

							<?php _e( 'Zoho CRM Sync', 'gloo_for_zoho_td' ); ?>
                            <small class="module-setting">
                                <a href="<?php echo admin_url( 'admin.php?page=gloo-zoho-setting' ); ?>"><?php _e( 'settings' ); ?></a>
                            </small>
                            <!-- <div class="gloo-tool">
                                <a href="#" class="tool-tip"></a>
                                <div class="tool-tip-content">
                                    <p><?php _e( '- Zoho CRM form action' ); ?></p>
                                    <p><?php _e( '- SalesForce CRM form action' ); ?></p>
                                </div>
                            </div>-->
                            
                        </lable>
                    </li>         
                </ul>
            </div>

            <div class="gloo-box"></div>
        </div>
        
    </div>
</div>
<?php include gloo_for_zoho()->plugin_path( 'includes/dashboard/views/common/admin-gloo-footer.php' ); ?>
