
 jQuery( document ).ready(function($) {

  function get_zoho_module_fields(value){
    return '';
  }
    $(document).on('DOMNodeInserted', 'body', function (e) {
      if($('.gloo_zoho_module_dropdown').length){
        $('.gloo_zoho_field_name select').addClass("otw_gloo_zoho_field_name");
        /*$('.gloo_zoho_field_name select.otw_gloo_zoho_field_name').html(
          '<option value="">--Select--</option>'+
          '<option value="1">1</option>'+
          '<option value="2">2</option>'
        );*/
        $('.gloo_zoho_module_dropdown').change(function(){

        });
      }
        
        /*$('.gloo_list_variable_name').find("input[type='text']").each(function(){       
            $(this).on("keypress, keydown, keyup", function(){
                
            });
            $(this).on("blur", function(){
               
            });
        });*/

    });



	function gloo_addPageCustomCss() {
		var customCSS = elementor.settings.page.model.get('gloo_custom_css');
		if (customCSS) {
			customCSS = customCSS.replace(/selector/g, elementor.config.settings.page.cssWrapperSelector);
			elementor.settings.page.getControlsCSS().elements.$stylesheetElement.append(customCSS);
		}
    }
    
  //  elementor.hooks.addFilter('editor/style/styleText', gloo_addCustomCss);
	//elementor.settings.page.model.on('change', gloo_addPageCustomCss);
	//elementor.on('preview:loaded', gloo_addPageCustomCss);
});
 