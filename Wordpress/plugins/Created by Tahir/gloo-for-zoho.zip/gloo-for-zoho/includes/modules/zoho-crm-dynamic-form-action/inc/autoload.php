<?php

include_once gloo_for_zoho()->modules_path().'zoho-crm-dynamic-form-action/inc/functions.php';

// add the data sanitization and validation class
if(!class_exists('BBWPSanitization'))
	include_once gloo_for_zoho()->modules_path().'zoho-crm-dynamic-form-action/inc/classes/BBWPSanitization.php';


spl_autoload_register( function ( $class ) {

	// project-specific namespace prefix
	$prefix = 'GlooForZoho\Modules\ZohoCrmDynamicFormAction';
	
	// If the specified $class does not include our namespace, duck out.
	if ( false === strpos( $class, 'GlooForZoho\Modules\ZohoCrmDynamicFormAction' ) ) {
		return; 
	}
	// base directory for the namespace prefix
	$base_dir = gloo_for_zoho()->modules_path().'zoho-crm-dynamic-form-action/inc/classes/';

	// does the class use the namespace prefix?
	$len = strlen( $prefix );

	// get the relative class name
	$relative_class = substr( $class, $len+1 );
	
	$file = $base_dir .  $relative_class  . '.php';

	// if the file exists, require it
	if ( file_exists( $file ) ) {
		include_once( $file );
	}
} );
