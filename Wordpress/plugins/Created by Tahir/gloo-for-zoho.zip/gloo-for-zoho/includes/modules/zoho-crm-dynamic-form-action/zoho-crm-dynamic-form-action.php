<?php

// exit if file is called directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Gloo_Module_Zoho_Crm_Sync' ) ) {

	/**
	 * Define Gloo_Module_Zoho_Crm_Sync class
	 */
	class Gloo_Module_Zoho_Crm_Sync extends gloo_for_zoho_Module_Base {

		public $instance = null;

		/**
		 * Module ID
		 *
		 * @return string
		 */
		public function module_id() {
			return 'zoho_crm_sync';
		}

		public function module_dependencies() {
			// array of label => plugin file path

			// return [
			// 	'WooCommerce' => 'woocommerce/woocommerce.php'
			// ];

			// or return boolean value
			// in this case checking for Buddypress and JetSmartFilters
			return [
				'ElementorPro'      => defined( 'ELEMENTOR_PRO_VERSION' ),
			];

		}

		/**
		 * Module name
		 *
		 * @return string
		 */
		public function module_name() {
			return __( 'Zoho Crm Sync', 'gloo' );
		}

		/**
		 * Module init
		 *
		 * @return void
		 */
		public function module_init() {
			add_action( 'gloo_for_zoho/init', array( $this, 'create_instance' ) );
		}

		/**
		 * Create module instance
		 *
		 * @return [type] [description]
		 */
		public function create_instance(  ) {
			require  gloo_for_zoho()->modules_path( 'zoho-crm-dynamic-form-action/inc/module.php' );
			$this->instance = \GlooForZoho\Modules\ZohoCrmDynamicFormAction\Module::instance();
		}

	}

}