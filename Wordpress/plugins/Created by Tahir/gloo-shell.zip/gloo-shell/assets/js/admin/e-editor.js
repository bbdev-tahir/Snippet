jQuery(window).on('load', function () {
    if (elementor) {
        // helper functions
        const addSelectOption = function (id, value, label) {
            jQuery('select[data-setting="' + id + '"]').append(new Option(label, value));
        }

        const updateSelectOption = function (value, label) {
            jQuery('select option[value="' + value + '"]').text(label).closest('select').select2();
            // console.log('updated ' + value);
        }

        const removeSelectOption = function (value) {
            jQuery('select option[value="' + value + '"]').remove();
            // console.log('removed ' + value);
        }

        const correctNamesAfterSort = function (titleName, collection) {
            if (collection.length) {
                jQuery.each(collection.models, function (index, value) {
                    var label = value.attributes[titleName] ? value.attributes[titleName] : 'Item #' + (index + 1)
                    updateSelectOption(value.attributes._id, label);
                });
            }
        }

        const addMissingSelectOptions = function (titleName, selectName, collection) {
            if (collection.length) {
                jQuery.each(collection.models, function (index, value) {
                    if (jQuery('select[data-setting="' + selectName + '"] option[value="' + value.attributes._id + '"]').length < 1) {
                        var label = value.attributes[titleName] ? value.attributes[titleName] : 'Item #' + (index + 1)
                        jQuery('select[data-setting="' + selectName + '"]').append(new Option(label, value.attributes._id));
                    }
                });
            }
        }


        const getEditorControlView = function (id) {
            const editor = elementor.getPanelView().getCurrentPageView();
            return editor.children.findByModelCid(editor.getControlModel(id).cid);
        };

        const linkRepeaterToSelect = function (repeaterName, selectName, titleName) {
            var repeaterControlView = getEditorControlView(repeaterName);
            repeaterControlView.collection
                .on('change', model => {
                    // console.log('change:', model);
                    var optionLabel = model.attributes[titleName],
                        optionValue = model.attributes._id;

                    if (!optionLabel) {
                        optionLabel = 'Item #' + model.collection.length;
                    }

                    updateSelectOption(optionValue, optionLabel);
                })
                .on('update', (collection, update) => {
                    // prevent adding if its just sorting
                    if (update.add && (collection.length == update.at + 1)) {
                        var optionLabel = 'Item #' + (update.at + 1),
                            optionValue = collection.models[update.at].attributes._id;

                        if (collection.models[update.at].attributes[titleName]) {
                            optionLabel = collection.models[update.at].attributes[titleName];
                        }

                        if (optionValue) {
                            addSelectOption(selectName, optionValue, optionLabel);
                        }
                        return false;
                        // return console.log('true add:', collection, update);
                    }

                    addMissingSelectOptions(titleName, selectName, collection);
                    correctNamesAfterSort(titleName, collection);
                    // return console.log('add on sort:', collection, update);
                })
                .on('remove', (model, collection) => {
                    var idToRemove = model.attributes._id;
                    // prevent removing if its just sorting
                    if (collection.models.findIndex(x => x.attributes._id === idToRemove) > 0) {
                        // console.log("not removed");
                        return false;
                    }
                    // not sorting, safe to remove
                    removeSelectOption(idToRemove);
                    // console.log('removed:', model);

                });
        };

        jQuery(document).one('click', '#elementor-panel-page-settings .elementor-tab-control-advanced', function () {

            // repeater, select, title
            linkRepeaterToSelect('gloo_interactor_triggers', 'gloo_interactor_condition_triggers', 'gloo_interactor_trigger_title');
            linkRepeaterToSelect('gloo_interactor_events', 'gloo_interactor_trigger_connect', 'gloo_interactor_event_title');
            linkRepeaterToSelect('gloo_interactor_events', 'gloo_interactor_event_next', 'gloo_interactor_event_title');

        });
    }
});