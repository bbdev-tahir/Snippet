<?php
/**
 * Plugin Name: Gloo Shell
 * Description: Gloo Shell
 * Version:     0.0.1
 * Author:      Gloo
 * Author URI:  http://gloo.ooo
 * Text Domain: gloo_shell_td
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

final class Gloo_For_Shell {

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		//call appsero tracker
		$this->appsero_init_tracker_gloo_for_elementor();

		// Load translation
		add_action( 'init', array( $this, 'i18n' ) );

		// Init Plugin
		add_action( 'plugins_loaded', array( $this, 'init' ) );

	}


	/** * Initialize the plugin tracker * * @return void */

	public function appsero_init_tracker_gloo_for_elementor() {    

		global $gloo_license;

		if ( ! class_exists( '\Appsero\Client' ) ) {   
			require_once __DIR__ . '/includes/appsero/src/Client.php';
		}
		
		$client = new \Appsero\Client( 'db5751b5-31e2-4bb6-8eea-8087654544e7', 'Gloo Shell', __FILE__ );
		// Active insights    
		
		$client->insights()->init();    
		
		// Active automatic updater    
		
		$client->updater();    
		
		// Active license page and checker    
		
		$args = array(
			'type'       => 'submenu',
			'menu_title' => 'Gloo Shell License',
			'page_title' => 'Gloo Shell License Settings',
			'menu_slug'  => 'gloo_shell_settings',
			'parent_slug' => 'gloo-shell-dashboard',
	);

		$gloo_license = $client->license();
		$gloo_license->add_settings_page( $args );

		//$gloo_license->set_option_key( 'gloo_shell_license_info' );

	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function i18n() {
		load_plugin_textdomain( 'gloo_shell_td' );
	}

	public function private_gloo() {
		global $wp_list_table;
		$hide       = array( 'gloo-suite/gloo-suite.php' );
		$my_plugins = $wp_list_table->items;
		foreach ( $my_plugins as $key => $val ) {
			if ( in_array( $key, $hide ) ) {
				unset( $wp_list_table->items[ $key ] );
			}
		}
	}

	/**
	 * Initialize the plugin
	 *
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed include the plugin class.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function init() {

		// Check if Elementor is installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_elementor_plugin' ] );

			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_minimum_php_version' ) );

			return;
		}
		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once( 'plugin.php' );

	}


	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'gloo_for_elementor' ),
			'<strong>' . esc_html__( 'Gloo For Elementor', 'gloo_for_elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'gloo_for_elementor' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	public function admin_notice_missing_elementor_plugin() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Gloo For Elementor for Elementor 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'gloo_for_elementor' ),
			'<strong>' . esc_html__( 'Gloo For Elementor', 'gloo_for_elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'gloo_for_elementor' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

}

// Instantiate Gloo_For_Elementor.
new Gloo_For_Shell();
