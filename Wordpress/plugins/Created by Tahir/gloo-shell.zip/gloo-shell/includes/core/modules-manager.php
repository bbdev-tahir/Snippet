<?php
/**
 * Modules manager
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

if ( ! class_exists( 'Gloo_Shell_Modules' ) ) {

	/**
	 * Define Gloo_Modules class
	 */
	class Gloo_Shell_Modules {

		public $option_name = 'gloo_shell_modules';
		private $modules = array();
		private $active_modules = array();

		/**
		 * Constructor for the class
		 */
		function __construct() {

			$this->preload_modules();
			$this->init_active_modules();
		}


		/**
		 * Activate module
		 *
		 * @return [type] [description]
		 */
		public function activate_module( $module ) {

			$modules = get_option( $this->option_name, array() );

			if ( ! in_array( $module, $modules ) ) {
				$modules[] = $module;
			}

			update_option( $this->option_name, $modules );

		}

		/**
		 * Returns path to file inside modules dir
		 *
		 * @param  [type] $path [description]
		 *
		 * @return [type]       [description]
		 */
		public function modules_path( $path ) {
			return gloo_shell()->modules_path() . $path;
		}

		/**
		 * Preload modules
		 *
		 * @return void
		 */
		public function preload_modules() {

			$base_path   = gloo_shell()->modules_path();
			$all_modules = apply_filters( 'gloo_shell/available-modules', array(				
				//'Gloo_Module_Zoho_Crm_Dynamic_Form_Action'   => $base_path . 'zoho-crm-dynamic-form-action/zoho-crm-dynamic-form-action.php',
			) );

			require_once gloo_shell()->plugin_path( 'includes/base/base-module.php' );

			foreach ( $all_modules as $module => $file ) {
				require $file;
				$instance                                = new $module;
				$this->modules[ $instance->module_id() ] = $instance;
			}

		}

		/**
		 * Initialize active modulles
		 *
		 * @return void
		 */
		public function init_active_modules() {


			$modules = $this->get_active_modules();

			if ( empty( $modules ) ) {
				return;
			}

			


			foreach ( $modules as $module => $is_active ) {

				if ( 'true' === $is_active ) {

					$module_instance = isset( $this->modules[ $module ] ) ? $this->modules[ $module ] : false;
					if ( $module_instance ) {

						call_user_func( array( $module_instance, 'module_init' ) );
						$this->active_modules[] = $module;
					}
				}
			}


		}

		/**
		 * Get all modules list in format required for JS
		 *
		 * @return [type] [description]
		 */
		public function get_all_modules_for_js() {

			$result = array();

			foreach ( $this->modules as $module ) {

				$result[] = array(
					'value' => $module->module_id(),
					'label' => $module->module_name(),
				);

			}

			return $result;

		}

		/**
		 * Get all modules list
		 *
		 * @return [type] [description]
		 */
		public function get_all_modules() {
			$result = array();
			foreach ( $this->modules as $module ) {
				$result[ $module->module_id() ] = $module->module_name();
			}

			return $result;
		}

		/**
		 * Get active modules list
		 *
		 * @return [type] [description]
		 */
		public function get_active_modules() {

			$active_modules = get_option( $this->option_name, array() );

			return $active_modules;
		}

		/**
		 * Check if pased module is currently active
		 *
		 * @param  [type]  $module_id [description]
		 *
		 * @return boolean            [description]
		 */
		public function is_module_active( $module_id = null ) {
			return in_array( $module_id, $this->active_modules );
		}

		/**
		 * Get module instance by module ID
		 *
		 * @param  [type] $module_id [description]
		 *
		 * @return [type]            [description]
		 */
		public function get_module( $module_id = null ) {
			return isset( $this->modules[ $module_id ] ) ? $this->modules[ $module_id ] : false;
		}

	}

}
