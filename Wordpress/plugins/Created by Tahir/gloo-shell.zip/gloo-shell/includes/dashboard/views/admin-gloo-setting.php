<?php
$gloo_license_info = get_option('gloo_shell_license_info');
$all_modules    = gloo_shell()->modules->get_all_modules();
$active_modules = gloo_shell()->modules->get_active_modules();

include gloo_shell()->plugin_path( 'includes/dashboard/views/common/admin-gloo-header.php' ); ?>
<div class="gloo-item-container">
    <img src="<?php echo $images_url . 'buildings.png' ?>" class="gloo-building"/>
    <div class="gloo-items">
        <!-- little engine -->
        <div class="gloo-feature">
            <div class="gloo-box">
                <div class="gloo-feature-title">
                    <img src="<?php echo $images_url . 'POWER GLOO header.jpg' ?>"/>
                </div>

                <div class="gloo-feature-status">
                    <a href="#" class="js-gloo-enable"><?php _e( 'Enable All' ); ?></a>
                    <a href="#" class="js-gloo-disable"><?php _e( 'Disable All' ); ?></a>
                </div>
                <ul>
                    <li>
                        <lable>
                            <input type="checkbox" class="flipswitch" value="1" name="css_content_visibility" <?php echo in_array(    'css_content_visibility', $active_modules ) ? 'checked="checked"' : ''; ?>/>
			                <?php _e( 'CSS: content-visibility' ); ?>
                        </lable>
                    </li>                   
                </ul>
            </div>

            <div class="gloo-box">
                <div class="gloo-feature-title">
                    <img src="<?php echo $images_url . 'SUPERGLOO ADDONS header.jpg' ?>"/>
                </div>
                <ul>
                    <li>
                        <lable>
                            <input type="checkbox" class="flipswitch" value="1" name="buddyboss_gloo_kit" <?php echo in_array( 'buddyboss_gloo_kit', $active_modules ) ? 'checked="checked"' : ''; ?> />

                            <?php _e( 'BuddyBoss Gloo Kit' ); ?>

                            <small class="module-setting"><a href="<?php echo admin_url( 'admin.php?page=gloo-buddyboss'); ?>"><?php _e( 'settings' ); ?></a></small>                            
                        </lable>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Fluid dynamics -->
        <div class="gloo-feature">
            <div class="gloo-box">
                <div class="gloo-feature-title"><img
                            src="<?php echo $images_url . 'FLUID DYNAMIC title only.jpg' ?>"/></div>

                <div class="gloo-feature-status">
                    <a href="#" class="js-gloo-enable"><?php _e( 'Enable All' ); ?></a>
                    <a href="#" class="js-gloo-disable"><?php _e( 'Disable All' ); ?></a>
                </div>
                <ul>
                   
                    <li>
                        <lable>
                            <input type="checkbox" class="flipswitch" value="1" name="gloo_dynamic_tag_maker" <?php echo in_array( 'gloo_dynamic_tag_maker', $active_modules ) ? 'checked="checked"' : ''; ?>/>
                            <?php _e( 'Data Sources Dynamic Tag' ); ?>
                        </lable>
                    </li>
                </ul>
            </div>
            <div class="gloo-support">
                
                <div class="gloo-fly">
                    <a href="https://desk.zoho.eu/portal/gloodesk/" target="_blank" class="gloo-btn-black"><?php _e( 'Support' ); ?></a>
                </div>
            </div>
        </div>
        <!-- Interactor -->
        <div class="gloo-feature">
            <div class="gloo-box">
                <div class="gloo-feature-title"><img
                            src="<?php echo $images_url . 'INTERACTOR TITLE ONLY.jpg' ?>"/></div>

                <div class="gloo-feature-status">
                    <a href="#" class="js-gloo-enable"><?php _e( 'Enable All' ); ?></a>
                    <a href="#" class="js-gloo-disable"><?php _e( 'Disable All' ); ?></a>
                </div>
                <ul>
                    
                    <li style="display: none;">
                        <div class="gloo-check">
                            <input type="checkbox" class="flipswitch" value="1" disabled/>
                        </div>
                        <?php _e( 'Ajax Module For Interactor' ); ?>
                    </li>
                </ul>

                <div class="gloo-support">
                    <div class="gloo-key">
                        <p><?php _e( 'Key:' ); ?></p>

                        <?php if(isset($gloo_license_info['key']) && !empty($gloo_license_info['key'])): ?>
                            <p><?php echo substr($gloo_license_info['key'],0,10).'********'; ?></p>
                        <?php else : ?>
                            <p><?php _e( 'NOT AVAILABLE' ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php include gloo_shell()->plugin_path( 'includes/dashboard/views/common/admin-gloo-features.php' ); ?>
            </div>
        </div>
    </div>
</div>
<?php include gloo_shell()->plugin_path( 'includes/dashboard/views/common/admin-gloo-footer.php' ); ?>
