<?php

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

/**
 * Class Plugin
 *
 * Main Plugin class
 */
if ( ! class_exists( 'GlooShell' ) ) {

	class GlooShell {

		/**
		 * Plugin Version
		 *
		 * @var string The plugin version.
		 */
		private $version = '0.0.1';

		public $modules;

		/**
		 * Instance
		 *
		 * @access private
		 * @static
		 *
		 * @var Plugin The single instance of the class.
		 */
		private static $_instance = null;

		/**
		 * Holder for base plugin path
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    string
		 */
		private $plugin_path = null;

		/**
		 * Holder for base plugin url
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    string
		 */
		private $plugin_url = null;


		/**
		 * Gloo menu page slug
		 *
		 * @var string
		 */
		public $admin_page = 'gloo-shell-dashboard';

		public $dashboard;

		/**
		 * Instance
		 *
		 * Ensures only one instance of the class is loaded or can be loaded.
		 *
		 * @return Gloo An instance of the class.
		 * @access public
		 *
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 *  Plugin class constructor
		 *
		 * Register plugin action hooks and filters
		 *
		 * @access public
		 */
		public function __construct() {


			// Load files.
			add_action( 'init', array( $this, 'init' ), - 999 );

			// Register activation and deactivation hook.
			register_activation_hook( __FILE__, array( $this, 'activation' ) );
			register_deactivation_hook( __FILE__, array( $this, 'deactivation' ) );

			add_action( 'init', function () {
				if ( ! isset( $_GET['test'] ) ) {
					return;
				}
				add_filter('jet-engine/elementor-views/frontend/listing-content' , function($content, $id){
					var_dump("THE ID IS: $content");
				},10, 2);

			} );

		}

		public function init() {

			// require module files
			require $this->plugin_path( 'includes/core/modules-manager.php' );

			$this->admin_init();
			
			// initialize modules
			$this->modules = new Gloo_Shell_Modules();
			// add widgets category of gloo
			add_action( 'elementor/init', [ $this, 'register_category' ] );
			
			// enqueue styles
			add_action( 'elementor/editor/before_enqueue_styles', [ $this, 'enqueue_editor_styles' ] );
			add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'icons_font_styles' ] );
			add_action( 'elementor/preview/enqueue_styles', [ $this, 'icons_font_styles' ] );
			add_action( 'elementor/dynamic_tags/register_tags', [ $this, 'register_dynamic_tags' ] );

			do_action( 'gloo_shell/init', $this );
		}


		public function admin_init() {
			if ( ! is_admin() ) {
				return;
			}

			require $this->plugin_path( 'includes/dashboard/manager.php' );

			$this->dashboard     = new Gloo_Shell_Dashboard();
		}


		public function enqueue_editor_styles() {
			wp_enqueue_style( 'gloo-shell-elementor-editor', $this->plugin_url() . '/assets/css/editor.css' );
		}

		/**
		 * Enqueue icons font styles
		 *
		 * @return void
		 */
		public function icons_font_styles() {

			wp_enqueue_style(
				'gloo-shell-elements-font',
				$this->plugin_url() . '/assets/css/admin/gloo-icons.css',
				array(),
				$this->version
			);

		}

		public function register_dynamic_tags() {

			\Elementor\Plugin::$instance->dynamic_tags->register_group( 'gloo-shell-dynamic-tags', [
				'title' => 'Gloo Shell Dynamic Tags'
			] );
	
		}

		/**
		 * Register gloo category for elementor if not exists
		 *
		 * @return void
		 */
		public function register_category() {

			$elements_manager = Elementor\Plugin::instance()->elements_manager;
			$cherry_cat       = 'gloo_shell';

			$elements_manager->add_category(
				$cherry_cat,
				array(
					'title' => esc_html__( 'Gloo Shell', 'gloo_shell_td' ),
					'icon'  => 'font',
				)
			);
		}

		/**
		 * Do some stuff on plugin activation
		 *
		 * @return void
		 * @since  1.0.0
		 */
		public function activation() {

		}

		/**
		 * Do some stuff on plugin activation
		 *
		 * @return void
		 * @since  1.0.0
		 */
		public function deactivation() {
		}

		/**
		 * Returns plugin version
		 *
		 * @return string
		 */
		public function get_version() {
			return $this->version;
		}


		/**
		 * Check if theme has elementor
		 *
		 * @return boolean
		 */
		public function has_elementor() {
			return defined( 'ELEMENTOR_VERSION' );
		}

		/**
		 * Check if theme has elementor
		 *
		 * @return boolean
		 */
		public function has_elementor_pro() {
			return defined( 'ELEMENTOR_PRO_VERSION' );
		}

		public function plugin_url( $path = null ) {

			if ( ! $this->plugin_url ) {
				$this->plugin_url = trailingslashit( plugin_dir_url( __FILE__ ) );
			}

			return $this->plugin_url . $path;
		}


		public function plugin_path( $path = null ) {

			if ( ! $this->plugin_path ) {
				$this->plugin_path = trailingslashit( plugin_dir_path( __FILE__ ) );
			}

			return $this->plugin_path . $path;
		}

		public function modules_path( $path = null ) {
			return $this->plugin_path( 'includes/modules/' ) . $path;
		}

	}
}

if ( ! function_exists( 'gloo_shell' ) ) {
	/**
	 * Returns instance of the plugin class.
	 *
	 * @return Gloo
	 * @since  1.0.0
	 */
	function gloo_shell() {
		return GlooShell::instance();
	}
}
// Instantiate Plugin Class
gloo_shell();
