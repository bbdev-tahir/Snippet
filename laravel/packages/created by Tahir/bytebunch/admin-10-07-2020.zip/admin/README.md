#First create authentication 
php artisan make:auth

#2nd Install Laravel passport for API Requests
composer require laravel/passport
php artisan migrate
php artisan passport:install