<?php

namespace Bytebunch\Admin\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

/*********Dummy */
use Bytebunch\Admin\Models\Permission;
use Bytebunch\Admin\Models\Role;
use Bytebunch\Admin\Models\User;
use function GuzzleHttp\json_encode;

/*********Dummy */

class AdminController extends Controller
{

    public function dashboard()
    {
        $data = array(
            'body_class' => 'admin dashboard template-backend-dashboard',
        );
        
        //app('PermissionRegistrar')->forgetCachedPermissions();
        //$permission = Permission::create(['name'=>'manage users']);
        //$permission = Permission::create(['name'=>'edit article']);
        //Role::create(['name' => 'writer']);
        //$permission = Permission::findByName('write post');
        //$permission = Permission::findById(3);

        //$role = Role::findByName('writer');
        //$role->givePermissionTo('write post');
        //$role->revokePermissionTo($permission);
        //$role->givePermissionTo($permission);
        //auth()->user()->assignRole('writer');
        //$permission->removeRole($role);
        //auth()->user()->givePermissionTo('write post', 'edit article');
        //auth()->user()->givePermissionTo('manage users');
        
        //dd(auth()->user()->getAllPermissions());
        //dd(User::permission('edit post')->get());
        //auth()->user()->revokePermissionTo('write post');
        //auth()->user()->removeRole('writer');
        return view('Admin::dashboard', $data);
    }

    public function usersIndex(){

        
    }

    public function userDelete(User $user){
        //$user->delete();
        return ['success' => true];
    }
    
}
