<?php

namespace Bytebunch\Admin\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Bytebunch\Admin\Models\User;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
			$data = array(
				'body_class' => 'admin users template-backend-users',
			);
            
            $users = User::select('id', 'name', 'email', 'updated_at')->orderBy('id', 'DESC')/*->with('roles')*/->paginate(2);
            $data['items'] = json_encode($users->items(), JSON_UNESCAPED_SLASHES );
            //$data['items'] = User::select('id', 'name', 'email', 'updated_at')->orderBy('id', 'DESC')/*->with('roles')*/->get();
            

			$data['urls'] = json_encode(array('app'=> url('/'), 'model' => 'users'), JSON_UNESCAPED_SLASHES );
            $data['columns'] = json_encode(array('ID', 'Name', 'Email', 'Date'));
            

            $data['pagination'] = json_encode( [
                    'total' => $users->total(),
                    'per_page' => $users->perPage(),
                    'current_page' => $users->currentPage(),
                    'last_page' => $users->lastPage(),
                    'from' => $users->firstItem(),
                    'to' => $users->lastItem()
            ], JSON_UNESCAPED_SLASHES );
			
			return view('Admin::users.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
			return view('Admin::users.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'email' => 'required|max:255|email:rfc,dns|unique:users,email',
            'fname' => 'required|min:2|max:255|alpha_dash',
            'lname' => 'nullable|max:255|alpha_dash',
            'password' => 'required|string|min:6|confirmed|regex:/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$/',
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
				$user = User::findOrFail($id);
				//$user->delete();
        return ['success' => true];
    }
}
