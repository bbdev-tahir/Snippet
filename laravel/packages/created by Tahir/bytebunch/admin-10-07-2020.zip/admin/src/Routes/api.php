<?php

/* ----------------------------------------------------------------------- */
/*
 * Backend API Routes
 */
Route::group(['middleware' => ['api']], function () {
    Route::group(['middleware' => ['auth:api']], function () {

        Route::prefix('api')->group(function(){
            Route::delete('users/{user}', 'Bytebunch\Admin\Controllers\UserController@destroy')->name('admin.users.destroy');        
        });
        //Route::prefix('admin')->middleware('roles:Administrator|Super Admin|Author')->group(function(){
            //Route::post('api/users/delete', '\Bytebunch\Admin\Controllers\AdminController@userDelete')->name('admin.user.delete');        
        //});

    });
});
