<?php

/* ----------------------------------------------------------------------- */
/*
 * Backend Routes
 */
Route::group(['middleware' => ['web']], function () {
    
    Route::prefix('admin')->middleware('roles:Administrator|Super Admin|Author')->group(function(){

        Route::get('/', 'Bytebunch\Admin\Controllers\AdminController@dashboard')->name('admin.dashboard');
				Route::get('/dashboard', 'Bytebunch\Admin\Controllers\AdminController@dashboard')->name('admin.dashboard');
				
				/*Route::resource('users', 'Bytebunch\Admin\Controllers\UserController', [
					'as' => 'admin'
				]);*/
				Route::get('/users', 'Bytebunch\Admin\Controllers\UserController@index')->name('admin.users.index');
				Route::post('/users', 'Bytebunch\Admin\Controllers\UserController@store')->name('admin.users.store');
				Route::get('/users/new', 'Bytebunch\Admin\Controllers\UserController@create')->name('admin.users.create');
				Route::get('/users/{users}/edit', 'Bytebunch\Admin\Controllers\UserController@edit')->name('admin.users.edit');
				//Route::post('/users/{users}', 'Bytebunch\Admin\Controllers\UserController@update')->name('admin.users.update');
    });

});
/*
 * Backend Routes End
 */
/* ----------------------------------------------------------------------- */

/*Auth::routes([
    'register' => false,
    'verify' => true,
    'reset' => false
]);*/

