
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'ByteBunch &#8211; Website Development Agency') }}</title>

    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="stylesheet" href="{{ asset('vendor/bytebunch/admin/css/vendor.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/bytebunch/admin/css/app.css') }}">
</head>

<body class="{{ isset($body_class) ? $body_class : '' }}">

<div id="bbwrap" class="container-fluid px-0">
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark bb-admin-bar py-sm-0 mb-2 mb-sm-0">
        <!--<div class="row">
            <div class="col-md-12">-->
            
                <!-- Brand -->
                <a class="navbar-brand" href="https://bytebunch.com/"><img src="{{ asset('vendor/bytebunch/admin/images/icon.png') }}" alt="ByteBunch"></a>


                
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#adminbarleftnav" aria-controls="adminbarleftnav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <ul class="collapse navbar-collapse navbar-nav" id="adminbarleftnav">
                    <li class="nav-item d-none d-sm-block">
                        <a href="#" class="nav-link toggle-sidebar-button">
                            <span><i class="fa fa-align-left"></i> &nbsp; Toggle Sidebar</span>
                        </a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="{{ url('/') }}"></i><span class="fa fa-home"></span> &nbsp; Visit Site</a>
                    </li>

                                       
                    <!-- Dropdown -->
                    <li class="nav-item dropdown">
                    <a class="nav-link " href="#" id="navbardrop" data-toggle="dropdown">
                    <i class="fa fa-plus"></i> &nbsp; New
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#">User</a>
                        <a class="dropdown-item" href="#">Page</a>
                    </div>
                    </li>

                    
                    <li class="nav-item dropdown ml-sm-auto">
                    <a class="nav-link" href="#" id="navbardrop" data-toggle="dropdown">
                    Howdy, 
                    @auth
                    {{ isset(Auth::user()->name) ? Auth::user()->name : Auth::user()->email }}
                    @endauth
                    
                     &nbsp; <i class="fa fa-user"></i>
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#">View Profile</a>
                        <a class="dropdown-item" href="#">Edit Profile</a>
                        <a class="dropdown-item" href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                            {{ __('Logout') }}
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </div>
                    </li>
                </ul>

            <!--</div>--><!-- col-md-12-->
        
        <!--</div>--><!-- row-->
    </nav>
    <!--<div class="row no-gutters">
        <div class="col-md-12 col-lg-12">-->
        <div class="content-menu-wrapper d-sm-flex align-items-stretch">
            <nav id="" class="bg-dark navbar-dark admin-menu-main sidebar">
                <ul class="nav flex-column py-3">
                    <li class="nav-item">
                        <a class="nav-link active" href="{{ route('admin.dashboard') }}">
                            <span class="menu-icon"><i class="fas fa-tachometer-alt"></i> &nbsp; </span> 
                            <span class="menu-name">Dashboard</span> 
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="#usersSubmenu" data-toggle="collapse" aria-expanded="false" class="nav-link dropdown-toggle">
                            <span class="menu-icon"><i class="fas fa-user"></i> &nbsp; </span> 
                            <span class="menu-name">Users</span> 
                        </a>
                        <ul class="collapse" id="usersSubmenu">
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('admin.users.index') }}">All Users</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Add New</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Your Profile</a>
                            </li>
                        </ul>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span class="menu-icon"><i class="fa fa-lock"></i> &nbsp; </span> 
                            <span class="menu-name">Permissions</span> 
                        </a>                        
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span class="menu-icon"><i class="fa fa-user-tag"></i> &nbsp; </span> 
                            <span class="menu-name">Roles</span> 
                        </a>                        
                    </li>
                    <li class="nav-item">
                        <a href="#pagesSubmenu" data-toggle="collapse" aria-expanded="false" class="nav-link dropdown-toggle">
                            <span class="menu-icon"><i class="fa fa-copy"></i> &nbsp; </span> 
                            <span class="menu-name">Pages</span> 
                        </a>
                        <ul class="collapse" id="pagesSubmenu">
                            <li class="nav-item">
                                <a class="nav-link" href="#">All Pages</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Add New</a>
                            </li>
                        </ul>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span class="menu-icon"><i class="fa fa-cog"></i> &nbsp; </span> 
                            <span class="menu-name">Settings</span> 
                        </a>                        
                    </li>
                    <li class="nav-item d-none d-sm-block" id="collapse-menu">                    
                        <a class="nav-link" href="#">
                            <span class="menu-icon"><i class="fa fa-arrow-circle-left"></i> &nbsp; </span> 
                            <span class="menu-name">Collapse menu</span> 
                        </a>
                    </li>
                </ul>
            </nav>
            
            <div id="bbcontent" class="p-4 pb-5">       
                @yield('content')
                <div id="bbfooter" class="">
                    <p class="float-left">
                        <span id="footer-thankyou">Thank you for creating with <a href="https://bytebunch.com/">ByteBunch</a>.</span>	
                    </p>
                    <p id="footer-upgrade" class="float-right">Version 0.1</p>
                </div>
            </div><!-- bbcontent-->

        </div><!--content-menu-wrapper-->
        <!-- </div>col-md-3-->
    <!--</div> row-->
</div><!-- bbwrap -->

<script src="{{ asset('vendor/bytebunch/admin/js/manifest.js') }}"></script>
<script src="{{ asset('vendor/bytebunch/admin/js/vendor.js') }}"></script>
<script src="{{ asset('vendor/bytebunch/admin/js/app.js') }}"></script>

</body>
</html>