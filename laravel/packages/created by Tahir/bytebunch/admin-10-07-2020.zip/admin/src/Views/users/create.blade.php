@extends('Admin::layouts.admin')

@section('content')
<h1>Create New User</h1>
    <form action="{{route('admin.users.store')}}" method="post">
		@csrf
			<!--<div class="row form-group">
				<div class="col-md-3">
					<label for="username"><strong>Username: </strong><span class="required">*</span></label>
				</div>
				<div class="col-md-5">
					<input type="text" name="username" id="username" value="" class="form-control">
				</div>
			</div> row-->

			<div class="row form-group">
				<div class="col-md-5">
					<label for="email"><strong>Email address:</strong><span class="required">*</span></label>
					<p class="description">Your contact email address.</p>
				</div>
				<div class="col-md-5">
					<input type="email" name="email" id="email" class="required form-control @error('email') is-invalid @enderror" required="required" value="{{ old('email') }}" />
					@error('email')
							<span class="invalid-feedback" role="alert">
									<strong>{{ $message }}</strong>
							</span>
					@enderror
				</div>
			</div>

			<div class="row form-group">
				<div class="col-md-5">
					<label for="fname"><strong>First Name: </strong><span class="required">*</span></label>
					<p class="description">Length must be between 3 characters and 20 characters.</p>
				</div>
				<div class="col-md-5">
					<input type="text" name="fname" id="fname" class="required form-control @error('fname') is-invalid @enderror" required="required" pattern=".{2,20}" title="2 min and 20 max characters" value="{{ old('fname') }}" />
					@error('fname')
							<span class="invalid-feedback" role="alert">
									<strong>{{ $message }}</strong>
							</span>
					@enderror
				</div>
			</div>
			<div class="row form-group">
				<div class="col-md-5">
					<label for="lname"><strong>Last Name:</strong></label>
					<p class="description">Length must be between 3 characters and 20 characters.</p>
				</div>
				<div class="col-md-5">
					<input type="text" name="lname" id="lname" value="{{ old('lname') }}" class="form-control @error('lname') is-invalid @enderror" />
				</div>
			</div>

			<div class="form-group row">
				<div class="col-md-5">
					<label for="password"><strong>{{ __('Password') }}</strong></label>
					<p class="description">Your password must be atleast 6 characters long, should contain at-least 1 Uppercase, 1 Lowercase, 1 Numeric and 1 special character.</p>
				</div>
				<div class="col-md-5">
						<input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

						@error('password')
								<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
								</span>
						@enderror
				</div>
		</div>

		<div class="form-group row">
			<div class="col-md-5">
				<label for="password-confirm"><strong>{{ __('Confirm Password') }}</strong></label>
			</div>
				<div class="col-md-5">
						<input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
				</div>
		</div>
			
			<div class="row form-group">
				<div class="col-md-5">
					<input type="submit" value="Submit" class="btn btn-info" />
				</div>
			</div>
			
		</form>
@endsection