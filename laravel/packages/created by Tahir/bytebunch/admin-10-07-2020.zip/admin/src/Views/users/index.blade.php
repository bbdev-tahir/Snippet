@extends('Admin::layouts.admin')

@section('content')
    <list-table :initial-items="{{ $items }}" :urls="{{ $urls }}" :columns="{{ $columns }}"></list-table>
    <pagination :pagination="{{ $pagination }}" :offset="2" @paginate="fetchPosts()"></pagination>
    <?php /* v-if="pagination.last_page > 1"*/ ?>
@endsection