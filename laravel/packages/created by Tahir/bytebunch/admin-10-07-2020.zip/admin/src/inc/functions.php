<?php 
if(!function_exists('alert')){
	function alert($alertText = 'Test')
	{
		echo '<script type="text/javascript">';
		echo "alert(\"$alertText\");";
		echo "</script>";
	}
}
if(!function_exists('db')){
	function db($array1)
	{
		echo "<pre>";
		var_dump($array1);
		echo "</pre>";
	}
}