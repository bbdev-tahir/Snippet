<?php

namespace Bytebunch\Admin;

use Illuminate\Support\ServiceProvider;

//Added by Service Provider ByteBunch
use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Collection;

class AdminServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot(Filesystem $filesystem)
    {

        // register our middlewares
        $this->app['router']->aliasMiddleware('roles', \Bytebunch\Admin\Middlewares\RoleMiddleware::class);        

        //load Routes
        $this->loadRoutesFrom(__DIR__.'/Routes/web.php');

        // register our Models
        $this->bindModels();

        // register our controllers
        $this->makeControllers();        

        //load Views
        $this->loadViewsFrom(__DIR__.'/Views', 'Admin');        
        
        //public assets to public folder
        //php artisan vendor:publish --tag=public --force
        $this->publishes([
            __DIR__.'/public' => public_path('vendor/bytebunch/admin'),
        ], 'public');
        
        
        //$this->loadMigrationsFrom(__DIR__.'/Database/Migrations'); //use this if you want don't want to move migrations to the database folder
        //php artisan vendor:publish --tag=migrations
        //php artisan db:seed --class=Bytebunch\Admin\Database\Seeds\DatabaseSeeder
        $this->publishes([
            __DIR__.'/Database/Migrations/create_permission_tables.php' => $this->getMigrationFileName($filesystem),
        ], 'migrations');

        //Extend Auth/User class
        //dd(config('auth.providers.users.model'));
        config(['auth.providers.users.model' => \Bytebunch\Admin\Models\User::class]);
        
        
    }

    /**
     * bindModels
     *
     * @return void
     */
    public function bindModels()
    {
        $this->app->bind('Role', Bytebunch\Admin\Models\Role::class);
        $this->app->bind('Page', Bytebunch\Admin\Models\Page::class);
    }

    /**
     * makeControllers
     *
     * @return void
     */
    public function makeControllers()
    {
        $this->app->make('Bytebunch\Admin\Controllers\AdminController');
    }
    

    /**
     * Returns existing migration file if found, else uses the current timestamp.
     *
     * @param Filesystem $filesystem
     * @return string
     */
    protected function getMigrationFileName(Filesystem $filesystem): string
    {
        $timestamp = date('Y_m_d_His');
        return $this->app->databasePath()."/migrations/{$timestamp}_create_permission_tables.php";
        return Collection::make($this->app->databasePath().DIRECTORY_SEPARATOR.'migrations'.DIRECTORY_SEPARATOR)
            ->flatMap(function ($path) use ($filesystem) {
                return $filesystem->glob($path.'*_create_permission_tables.php');
            })->push($this->app->databasePath()."/migrations/{$timestamp}_create_permission_tables.php")
            ->first();
    }

}
