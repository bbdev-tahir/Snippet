<?php

namespace Bytebunch\Admin\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AdminController extends Controller
{

    public function dashboard()
    {
        $data = array(
            'body_class' => 'admin dashboard template-backend-dashboard',
        );
        
        return view('Admin::dashboard', $data);
    }
}
