<?php

namespace Bytebunch\Admin\Database\Seeds;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(\Bytebunch\Admin\Database\Seeds\RoleTableSeeder::class);
        $this->call(\Bytebunch\Admin\Database\Seeds\UserTableSeeder::class);
    }
}
