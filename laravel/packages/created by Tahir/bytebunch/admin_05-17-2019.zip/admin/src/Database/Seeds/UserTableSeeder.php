<?php

namespace Bytebunch\Admin\Database\Seeds;

use Illuminate\Database\Seeder;
use Bytebunch\Admin\Models\User;
use Bytebunch\Admin\Models\Role;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $roles = Role::where('name', 'Super Admin')->first();
        $user = new User();
        $user->name = 'ByteBunch';
        $user->email = 'admin@bytebunch.com';
        $user->password = bcrypt('bytebunchadmin');
        $user->save();
        $user->roles()->attach($roles);
        //$user->roles()->attach($roles_administrator);
    }
}
