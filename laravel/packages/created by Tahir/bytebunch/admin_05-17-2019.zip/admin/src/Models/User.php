<?php

namespace Bytebunch\Admin\Models;


/**
 * Class User
 * @package Package\Sample
 */
class User extends \App\User
{

    public function roles(){
        return $this->belongsToMany('Bytebunch\Admin\Models\Role', 'user_role', 'user_id', 'role_id');
    }

    public function hasAnyRole($roles){
        
        if(is_array($roles)){
            foreach($roles as $role){
                if($this->hasRole($role)){
                    return true;
                }
            }
        }elseif ($roles && $this->hasRole($role)) {
           return true;
        }
        return false;
    }

    public function hasRole($role){
        
        if($this->roles()->where('name', $role)->first()){
            return true;
        }
        return false;
    }
}