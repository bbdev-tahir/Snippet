<?php

/* ----------------------------------------------------------------------- */
/*
 * Backend Routes
 */
Route::group(['middleware' => ['web']], function () {
    //dd($this->app['router']);
    //Route::prefix('admin')->middleware('auth')->group(function(){
    Route::prefix('admin')->middleware('roles:Administrator|Super Admin')->group(function(){
        Route::get('/', 'Bytebunch\Admin\Controllers\AdminController@dashboard')->name('admin.dashboard');
        Route::get('/dashboard', 'Bytebunch\Admin\Controllers\AdminController@dashboard')->name('admin.dashboard');
    });

});
/*
 * Backend Routes End
 */
/* ----------------------------------------------------------------------- */

/*Auth::routes([
    'register' => false,
    'verify' => true,
    'reset' => false
]);*/

