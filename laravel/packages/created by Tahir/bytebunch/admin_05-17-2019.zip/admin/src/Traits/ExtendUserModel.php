<?php

namespace Bytebunch\Admin\Traits;

trait ExtendUserModel{

    
}