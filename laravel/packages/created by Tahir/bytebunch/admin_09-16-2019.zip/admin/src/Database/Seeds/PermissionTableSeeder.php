<?php

namespace Bytebunch\Admin\Database\Seeds;

use Illuminate\Database\Seeder;
use Bytebunch\Admin\Models\Permission;
use Bytebunch\Admin\Models\Role;

class PermissionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $roles = Role::where('name', 'Super Admin')->orWhere('name', 'Administrator')->first();
        $newPermission = new Permission();
        $newPermission->name = 'manage-users';
        $newPermission->save();
        $newPermission->roles()->attach($roles);

    }
}
