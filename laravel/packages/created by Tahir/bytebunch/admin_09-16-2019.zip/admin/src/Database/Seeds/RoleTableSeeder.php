<?php

namespace Bytebunch\Admin\Database\Seeds;

use Illuminate\Database\Seeder;
use Bytebunch\Admin\Models\Role;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $user_role = new Role();
        $user_role->name = 'Super Admin';
        $user_role->save();

        $user_role = new Role();
        $user_role->name = 'Administrator';
        $user_role->save();

        $user_role = new Role();
        $user_role->name = 'Author';
        $user_role->save();

        $user_role = new Role();
        $user_role->name = 'Subscriber';
        $user_role->save();
    }
}
