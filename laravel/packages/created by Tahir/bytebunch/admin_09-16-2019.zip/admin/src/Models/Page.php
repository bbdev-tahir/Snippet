<?php

namespace Bytebunch\Admin\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    
}
