<?php

namespace Bytebunch\Admin\Traits;
//use Bytebunch\Admin\Traits\RefreshesPermissionCache;


trait RefreshesPermissionCache
{
    public static function bootRefreshesPermissionCache()
    {
        static::saved(function () {
            app("PermissionRegistrar")->forgetCachedPermissions();
        });

        static::deleted(function () {
            app("PermissionRegistrar")->forgetCachedPermissions();
        });
    }
}
