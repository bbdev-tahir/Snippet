@extends('Admin::layouts.admin')

@section('content')
    <list-table :initial-items="{{ $items }}" :urls="{{ $urls }}" :columns="{{ $columns }}"></list-table>
@endsection