<template>
    <div class="wrap">
    <h1>Users <a :href=addNewUrl() class="btn-page-title-action">Add New</a></h1>    
    <table class="table table-striped" v-if="items.length">
        <thead>
            <tr>
                <th class="" style="width:2.2rem;"><input id="cb-select-all-1" type="checkbox"></th>
                <th class="">Title</th>
                <th class="w-10">Author</th>
                <th class="w-10">Date</th>
            </tr>
        </thead>
    <tbody>
      <tr v-for="(item, index) in items" :key="item.id">
        <td><input id="cb-select-" type="checkbox" name="post[]" :value=item.id></td>
        <td>
            <strong><a href="#">{{ item.name }}</a></strong>
            <div class="row-actions">
                <span class="edit"><a :href=editUrl(item.id) aria-label="Edit “Contact”">Edit</a> | </span>
                <span class="delete"><a :href=deleteUrl(item.id) class="submitdelete" @click.stop.prevent="removeItem(index)">Delete</a> | </span>
                <span class="view"><a :href=item.id rel="bookmark" aria-label="View “Contact”">View</a></span>
                </div>
            </td>
        <td>ByteBunch</td>
        <td class="date column-date" data-colname="Date">Published<br><abbr title="2018/07/13 5:02:31 am">2018/07/13</abbr></td>
      </tr>
      </tbody>
      <tfoot>
            <tr>
                <th><input id="cb-select-all-1" type="checkbox"></th>
                <th>Title</th>
                <th>Author</th>
                <th>Date</th>
            </tr>
        </tfoot>
  </table>
  </div>
</template>

<script>
export default {
    props : ['initialItems', 'urls', 'columns'],
    data() {
        return {
            items : _.cloneDeep(this.initialItems)
        }
    },
    /*created () {
        axios.post('http://localhost/bytebunch.com/staging/public/api/users/delete');
    },*/
    methods : { 
        removeItem(index){
            if(confirm("Are you sure?")){
                let id = this.items[index].id;
                if(id > 0){
                    axios.delete(this.urls.app+"/api/"+this.urls.model+"/"+id);
                }
                this.items.splice(index, 1);
            }
            return false;
        },//removeItem method End here
        deleteUrl(id){
            return this.urls.app+"/api/"+this.urls.model+"/"+id;
        },//deleteUrl method End here
        addNewUrl(){
            return this.urls.app+"/admin/"+this.urls.model+"/new";
        },//deleteUrl method End here
        editUrl(id){
            return this.urls.app+"/admin/"+this.urls.model+"/"+id;
        }
    }
}
</script>

<style>
.table-striped{
    border: 1px solid #e5e5e5;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}
.row-actions{
    margin-top:10px;
}
.table-striped tbody tr:nth-of-type(odd){
    background-color: #f9f9f9;
}

</style>


