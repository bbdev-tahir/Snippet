<?php

namespace Bytebunch\Admin;

use Illuminate\Support\ServiceProvider;

//Added by Service Provider ByteBunch
use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Gate;

class AdminServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     */
    /*protected $policies = [
        Bytebunch\Admin\Models\Page::class => Bytebunch\Admin\Policies\PagePolicy::class,
    ];*/

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot(PermissionRegistrar $permissionLoader, Filesystem $filesystem)
    {
        
        // register our middlewares
        $this->app['router']->aliasMiddleware('roles', \Bytebunch\Admin\Middlewares\RoleMiddleware::class);
        // register laravel passport middleware to web group.
        $this->app['router']->pushMiddlewareToGroup('web', \Laravel\Passport\Http\Middleware\CreateFreshApiToken::class);        

        //load Routes
        $this->loadRoutesFrom(__DIR__.'/Routes/web.php');
        $this->loadRoutesFrom(__DIR__.'/Routes/api.php');

        // register our Models
        $this->bindModels();

        // register our controllers
        $this->makeControllers();        

        //load Views
        $this->loadViewsFrom(__DIR__.'/Views', 'Admin');        
        
        //public assets to public folder
        //php artisan vendor:publish --tag=public --force
        $this->publishes([
            __DIR__.'/public' => public_path('vendor/bytebunch/admin'),
        ], 'public');
        
        
        //$this->loadMigrationsFrom(__DIR__.'/Database/Migrations'); //use this if you want to move migrations to the database folder
        
        //php artisan vendor:publish --tag=migrations
        //php artisan db:seed --class=Bytebunch\Admin\Database\Seeds\DatabaseSeeder
        $this->publishes([
            __DIR__.'/Database/Migrations/create_permission_tables.php' => $this->getMigrationFileName($filesystem),
        ], 'migrations');

        //Extend Auth/User class
        //dd(config('auth.providers.users.model'));
        config(['auth.providers.users.model' => \Bytebunch\Admin\Models\User::class]);

        //Use passport API package
        config(['auth.guards.api.driver' => "passport"]);

        // Implicitly grant "Super Admin" role all permissions
        // This works in the app by using gate-related functions like auth()->user->can() and @can()
        Gate::before(function ($user, $ability) {
            return $user->hasRole('Super Admin') ? true : null;
        });
        
        //register our policies defined in protected policies varialble
        //$this->registerPolicies();

        $permissionLoader->registerPermissions();

        $this->app->singleton(/*PermissionRegistrar::class*/'PermissionRegistrar', function ($app) use ($permissionLoader) {
            return $permissionLoader;
        });
        
    }

    /**
     * bindModels
     *
     * @return void
     */
    public function bindModels()
    {
        $this->app->bind('Role', Bytebunch\Admin\Models\Role::class);
        $this->app->bind('Page', Bytebunch\Admin\Models\Page::class);
    }

    /**
     * makeControllers
     *
     * @return void
     */
    public function makeControllers()
    {
        $this->app->make('Bytebunch\Admin\Controllers\AdminController');
    }
    

    /**
     * Returns existing migration file if found, else uses the current timestamp.
     *
     * @param Filesystem $filesystem
     * @return string
     */
    protected function getMigrationFileName(Filesystem $filesystem): string
    {
        $timestamp = date('Y_m_d_His');
        return $this->app->databasePath()."/migrations/{$timestamp}_create_permission_tables.php";
        return Collection::make($this->app->databasePath().DIRECTORY_SEPARATOR.'migrations'.DIRECTORY_SEPARATOR)
            ->flatMap(function ($path) use ($filesystem) {
                return $filesystem->glob($path.'*_create_permission_tables.php');
            })->push($this->app->databasePath()."/migrations/{$timestamp}_create_permission_tables.php")
            ->first();
    }

    /**
     * registerPolicies
     *
     * @return void
     */
    public function registerPolicies()
    {
        foreach ($this->policies as $key => $value) {
            Gate::policy($key, $value);
        }
    }

}
