<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePermissionTables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        
        Schema::create('permissions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->timestamps();
        });

        Schema::create('roles', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->timestamps();
        });

        

        Schema::create('role_has_permissions', function (Blueprint $table){
            $table->unsignedBigInteger('permission_id');
            $table->unsignedBigInteger('role_id');

            $table->foreign('permission_id')
                ->references('id')
                ->on('permissions')
                ->onDelete('cascade');

            $table->foreign('role_id')
                ->references('id')
                ->on('roles')
                ->onDelete('cascade');

            $table->primary(['permission_id', 'role_id']);
        });

        Schema::create('user_has_permissions', function (Blueprint $table) {
            $table->unsignedBigInteger('permission_id');

            $table->unsignedBigInteger('user_id');
            $table->index(['user_id']);

            $table->foreign('permission_id')
                ->references('id')
                ->on('permissions')
                ->onDelete('cascade');

            $table->primary(['permission_id', 'user_id']
                //,'user_has_permissions_permission_model_type_primary'
            );
        });

        Schema::create('user_has_roles', function (Blueprint $table){
            $table->unsignedBigInteger('role_id');

            $table->unsignedBigInteger('user_id');
            $table->index(['user_id']);

            $table->foreign('role_id')
                ->references('id')
                ->on('roles')
                ->onDelete('cascade');

            $table->primary(['role_id', 'user_id']
                //,'user_has_roles_role_model_type_primary'
            );
        });

        /*
         * You may optionally indicate a specific cache driver to use for permission and
         * role caching using any of the `store` drivers listed in the cache.php config
         * file. Using 'default' here means to use the `default` set in cache.php.
         */
        app('cache')
            ->store('default' != 'default' ? 'default' : null)
            ->forget('bytebunch.permission.cache');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('permissions');
        Schema::dropIfExists('roles');        
        Schema::dropIfExists('role_has_permissions');        
        Schema::dropIfExists('user_has_permissions');
        Schema::dropIfExists('user_has_roles');
        //Schema::dropIfExists('user_role');
        
    }
}
