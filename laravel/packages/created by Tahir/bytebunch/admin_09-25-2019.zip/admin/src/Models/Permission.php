<?php

namespace Bytebunch\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Bytebunch\Admin\Traits\RefreshesPermissionCache;
use Bytebunch\Admin\Traits\HasRole;

class Permission extends Model
{
    use RefreshesPermissionCache;
    use HasRole;
    
    protected $guarded = ['id'];
    

    public static function create(array $attributes = [])
    {
        $permission = static::getPermissions(['name' => $attributes['name']])->first();
        
        if ($permission) {
            abort(403, "Permission Already Exists by Name ".$attributes['name']);
            //dd("PermissionAlreadyExists");
            //throw PermissionAlreadyExists::create($attributes['name']);
        }

        return static::query()->create($attributes);
    }

    /**
     * A permission can be applied to roles.
     */
    public function roles()
    {
        return $this->belongsToMany(
            'Bytebunch\Admin\Models\Role',
            'role_has_permissions',
            'permission_id',
            'role_id'
        );
    }

    /**
     * A permission belongs to some users of the model associated with its guard.
     */
    public function users()
    {
        /*return $this->morphedByMany(
            getModelForGuard($this->attributes['guard_name']),
            'model',
            'model_has_permissions',
            'permission_id',
            'model_id'
        );*/

        /*return $this->morphedByMany(
            'Bytebunch\Admin\Models\User',
            'users',
            'user_has_permissions',
            'permission_id',
            'user_id'
        );*/

        return $this->belongsToMany(
            'Bytebunch\Admin\Models\User',
            'user_has_permissions',
            'permission_id',
            'user_id'
        );
    }

    /**
     * Find a permission by its name (and optionally guardName).
     *
     * @param string $name
     * @param string|null $guardName
     *
     * @throws \Spatie\Permission\Exceptions\PermissionDoesNotExist
     *
     * @return \Spatie\Permission\Contracts\Permission
     */
    public static function findByName(string $name)
    {
        $permission = static::getPermissions(['name' => $name])->first();
        if (! $permission) {
            abort( 403, "PermissionDoesNotExist by name ".$name,);
            //dd("PermissionDoesNotExist by name ".$name);
            //throw PermissionDoesNotExist::create($name);
        }
        return $permission;
    }

    /**
     * Find a permission by its id (and optionally guardName).
     *
     * @param int $id
     * @param string|null $guardName
     *
     * @throws \Spatie\Permission\Exceptions\PermissionDoesNotExist
     *
     * @return \Spatie\Permission\Contracts\Permission
     */
    public static function findById(int $id)
    {
        $permission = static::getPermissions(['id' => $id])->first();

        if (! $permission) {
            dd("PermissionDoesNotExist with id ".$id);
            //throw PermissionDoesNotExist::withId($id);
        }

        return $permission;
    }

    /**
     * Find or create permission by its name (and optionally guardName).
     *
     * @param string $name
     * @param string|null $guardName
     *
     * @return \Spatie\Permission\Contracts\Permission
     */
    public static function findOrCreate(string $name, $guardName = null)
    {
        
        $permission = static::getPermissions(['name' => $name])->first();

        if (! $permission) {
            return static::query()->create(['name' => $name]);
        }

        return $permission;
    }

    /**
     * Get the current cached permissions.
     */
    protected static function getPermissions(array $params = [])
    {
        return app('PermissionRegistrar')->getPermissions($params);
    }
}
