<?php

namespace Bytebunch\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Bytebunch\Admin\Traits\HasPermissions;
use Bytebunch\Admin\Traits\RefreshesPermissionCache;

class Role extends Model
{
    //
    use RefreshesPermissionCache;
    use HasPermissions;

    public function users(){
        return $this->belongsToMany('Bytebunch\Admin\Models\User', 'user_role', 'role_id', 'user_id');
    }

    protected $guarded = ['id'];

    public static function create(array $attributes = [])
    {
        
        if (static::where('name', $attributes['name'])->first()) {
            dd("RoleAlreadyExists by name ".$attributes['name']);
            //abort("RoleAlreadyExists", 403);
            //throw RoleAlreadyExists::create($attributes['name']);
        }

        return static::query()->create($attributes);
    }

    /**
     * A role may be given various permissions.
     */
    public function permissions()
    {
        return $this->belongsToMany(
            'Bytebunch\Admin\Models\Permission',
            'role_has_permissions',
            'role_id',
            'permission_id'
        );
    }

    /**
     * A role belongs to some users of the model associated with its guard.
     */
    /*public function users(): MorphToMany
    {
        return $this->morphedByMany(
            getModelForGuard($this->attributes['guard_name']),
            'model',
            config('permission.table_names.model_has_roles'),
            'role_id',
            config('permission.column_names.model_morph_key')
        );
    }*/

    /**
     * Find a role by its name and guard name.
     *
     * @param string $name
     * @param string|null $guardName
     *
     * @return \Spatie\Permission\Contracts\Role|\Spatie\Permission\Models\Role
     *
     * @throws \Spatie\Permission\Exceptions\RoleDoesNotExist
     */
    public static function findByName(string $name)
    {
        $role = static::where('name', $name)->first();

        if (! $role) {
            dd("There is no role named ".$name.".");
            //return ;
            //throw RoleDoesNotExist::named($name);
        }

        return $role;
    }

    public static function findById(int $id)
    {
        
        $role = static::where('id', $id)->first();

        if (! $role) {
            dd("RoleDoesNotExist");
            //throw RoleDoesNotExist::withId($id);
        }

        return $role;
    }

    /**
     * Find or create role by its name (and optionally guardName).
     *
     * @param string $name
     * @param string|null $guardName
     *
     * @return \Spatie\Permission\Contracts\Role
     */
    public static function findOrCreate(string $name)
    {
        
        $role = static::where('name', $name)->first();

        if (! $role) {
            return static::query()->create(['name' => $name]);
        }

        return $role;
    }

    /**
     * Determine if the user may perform the given permission.
     *
     * @param string|Permission $permission
     *
     * @return bool
     *
     * @throws \Spatie\Permission\Exceptions\GuardDoesNotMatch
     */
    public function hasPermissionTo($permission): bool
    {
        $permissionClass = $this->getPermissionClass();

        if (is_string($permission)) {
            $permission = $permissionClass->findByName($permission);
        }

        if (is_int($permission)) {
            $permission = $permissionClass->findById($permission);
        }

        return $this->permissions->contains('id', $permission->id);
    }
}
