<?php

/* ----------------------------------------------------------------------- */
/*
 * Backend Routes
 */
Route::group(['middleware' => ['web']], function () {
    
    Route::prefix('admin')->middleware('roles:Administrator|Super Admin|Author')->group(function(){

        Route::get('/', 'Bytebunch\Admin\Controllers\AdminController@dashboard')->name('admin.dashboard');
        Route::get('/dashboard', 'Bytebunch\Admin\Controllers\AdminController@dashboard')->name('admin.dashboard');
        Route::get('/users', 'Bytebunch\Admin\Controllers\AdminController@usersIndex')->name('admin.users.index');
    });

});
/*
 * Backend Routes End
 */
/* ----------------------------------------------------------------------- */

/*Auth::routes([
    'register' => false,
    'verify' => true,
    'reset' => false
]);*/

