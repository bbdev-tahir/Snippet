<?php

namespace Bytebunch\Admin\Traits;
//use Bytebunch\Admin\Traits\HasPermissions;

trait HasPermissions{

    private $permissionClass;

    /**
     * Grant the given permission(s) to a role.
     *
     * @param string|array|\Spatie\Permission\Contracts\Permission|\Illuminate\Support\Collection $permissions
     *
     * @return $this
     */

    // For Model = Role, User
    public function givePermissionTo(...$permissions)
    {
        //dd($permissions);
        $permissions = collect($permissions)
            ->flatten()
            ->map(function ($permission) {
                if (empty($permission)) {
                    return false;
                }
                return $this->getStoredPermission($permission);
            })
            /*->filter(function ($permission) {
                return $permission instanceof Permission;
            })*/
            ->map->id
            ->all();
        $model = $this->getModel();
        if ($model->exists) { 
            $this->permissions()->sync($permissions, false);
            $model->load('permissions');
        } else {
            $class = \get_class($model);

            $class::saved(
                function ($object) use ($permissions, $model) {
                    static $modelLastFiredOn;
                    if ($modelLastFiredOn !== null && $modelLastFiredOn === $model) {
                        return;
                    }
                    $object->permissions()->sync($permissions, false);
                    $object->load('permissions');
                    $modelLastFiredOn = $object;
                }
            );
        }

        $this->forgetCachedPermissions();

        return $this;
    }

    
    /**
     * @param string|array|\Spatie\Permission\Contracts\Permission|\Illuminate\Support\Collection $permissions
     *
     * @return \Spatie\Permission\Contracts\Permission|\Spatie\Permission\Contracts\Permission[]|\Illuminate\Support\Collection
     */
    // For Model = Role, User
    protected function getStoredPermission($permissions)
    {
        
        $permissionClass = $this->getPermissionClass();
        //db($permissionClass);
        if (is_numeric($permissions)) {
            return $permissionClass->findById($permissions);
        }
        
        if (is_string($permissions)) {
            return $permissionClass->findByName($permissions);
        }
        
        if (is_array($permissions)) {
            return $permissionClass
                ->whereIn('name', $permissions)
                ->get();
        }
        
        return $permissions;
    }

    /**
     * Revoke the given permission.
     *
     * @param \Spatie\Permission\Contracts\Permission|\Spatie\Permission\Contracts\Permission[]|string|string[] $permission
     *
     * @return $this
     */
    public function revokePermissionTo($permission)
    {
        $this->permissions()->detach($this->getStoredPermission($permission));

        $this->forgetCachedPermissions();

        $this->load('permissions');

        return $this;
    }

    public function getPermissionClass()
    {
        if (! isset($this->permissionClass)) {
            $this->permissionClass = app("PermissionRegistrar")->getPermissionClass();
        }
        return $this->permissionClass;
    }

    /**
     * Forget the cached permissions.
     */
    public function forgetCachedPermissions()
    {
        app("PermissionRegistrar")->forgetCachedPermissions();
    }

}