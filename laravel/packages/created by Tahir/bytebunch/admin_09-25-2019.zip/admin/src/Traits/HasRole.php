<?php

namespace Bytebunch\Admin\Traits;
//use Bytebunch\Admin\Traits\HasRole;


use Bytebunch\Admin\Traits\HasPermissions;

trait HasRole{

    use HasPermissions;

    private $roleClass;

    /**
     * Revoke the given role from the model.
     *
     * @param string|\Spatie\Permission\Contracts\Role $role
     */
    public function removeRole($role)
    {
        $this->roles()->detach($this->getStoredRole($role));

        $this->load('roles');

        return $this;
    }

    protected function getStoredRole($role)
    {
        $roleClass = $this->getRoleClass();

        if (is_numeric($role)) {
            return $roleClass->findById($role);
        }

        if (is_string($role)) {
            return $roleClass->findByName($role);
        }

        return $role;
    }

    public function getRoleClass()
    {
        if (! isset($this->roleClass)) {
            $this->roleClass = app("PermissionRegistrar")->getRoleClass();
        }

        return $this->roleClass;
    }
}