<?php

namespace Bytebunch\Permission\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AdminController extends Controller
{
    //
    public function dashboard()
    {
        $data = array(
            'body_class' => 'admin dashboard template-backend-dashboard',
        );
        return view('backend.dashboard', $data);
    }
}
