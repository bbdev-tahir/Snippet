<?php

namespace Bytebunch\Permission;

use Illuminate\Support\ServiceProvider;
//use Illuminate\Support\Facades\Route;

class PermissionServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        ////register module
        //$this->app->bind('option', \Appstract\Options\Option::class);

        // register our controller
        $this->app->make('Bytebunch\Permission\Controllers\AdminController');


        //load Views
        $this->loadViewsFrom(__DIR__.'/views', 'Permission');
        
        // make views customizable by package user.
        $this->publishes([
            __DIR__.'/views' => resource_path('views/vendor/Permission'),
        ]);
        //php artisan vendor:publish        

        //public assets to public folder
        $this->publishes([
            __DIR__.'/../public' => public_path('vendor/Permission'),
        ], 'public');
        //php artisan vendor:publish --tag=public --force

        //publishes
        $this->publishes([
            __DIR__.'/../config/package.php' => config_path('package.php')
        ], 'config');
        //php artisan vendor:publish --tag=config
    

        //$this->loadMigrationsFrom(__DIR__.'/path/to/migrations'); //use this if you want don't want to move migrations to the database folder
        $this->publishes([
            __DIR__.'/../database/migrations/' => database_path('migrations')
        ], 'migrations');
        //php artisan vendor:publish --tag=migrations
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadRoutesFrom(__DIR__.'/routes/web.php');
        //include __DIR__.'/routes/web.php';
        $this->app['router']->get('package-route', function(){
            return "I just dynamically registered a route out of my package";
        });     
    }

    /*public function map()
    {
        $this->mapWebRoutes();
    }

    protected function mapWebRoutes()
    {
        

        Route::prefix('Mypackage')
            ->middleware('web')
            ->namespace($this->namespace)
            ->group(__DIR__ . '\..\Routes\web.php');

        Route::get('calculator', function(){
            echo 'Hello from the calculator package!';
        });
    }*/
}
