<?php

Route::get('testa', function(){
	echo 'Hello from the calculator package!';
});