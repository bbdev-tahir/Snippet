<!DOCTYPE html>
<html>
<head>
	<title>Calculator</title>
</head>
<body>
	<h1 style="text-align:center">
		Your Result 
		
	</h1>
</body>
</html>